package com.example.tutorly;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/*Class to hold a record of the user's previously scheduled sessions*/
public class SessionHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_history);
    }
}
