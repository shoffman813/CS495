## [Home](README.md) || [Project Deliverables](project-deliverables.md) || [About Us](about-us.md)
# About Us
## Mitchell Parse
I am a senior computer science student at The University of Alabama. I am also part of the STEM Path to the MBA program at UA and will be finishing my MBA degree May of 2020.

## Savannah Hoffman
I am a senior at the University of Alabama with a major in computer science and a minor in math. I am graduating in May 2019.

## Elysse Kimmel
I am a senior Computer Science student and the University of Alabama. I plan to graduate in May 2019 and will be returning to UA next year to pursue an MBA. 

## Jack Hawblitzel
I am currently a senior at the University of Alabama majoring in computer science.  I will graduate in May and return next year to get my MBA with a concentration in financial engineering.
